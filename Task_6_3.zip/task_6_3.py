users = open('users.csv', 'r', encoding='utf-8')
hobby = open('hobby.csv', 'r', encoding='utf-8')
initials_list = []
hobby_list = []

for users_1 in (users.read().split('\n')):
    a = users_1.split(',')
    initials_list.append(a[0][0] + a[1][0] + a[2][0])

for hobby_1 in (hobby.read().split('\n')):
    hobby_list.append(hobby_1)

peoples_hobbies = {}
i = 0
while i < len(initials_list):
    if len(initials_list) > len(hobby_list):
        if i < len(hobby_list):
            peoples_hobbies[initials_list[i]] = hobby_list[i]
        else:
            peoples_hobbies[initials_list[i]] = None
        i += 1
    else:
        exit(1)
hobby_file = open('peoples_hobbies.txt', 'w+', encoding='utf-8')
for b in peoples_hobbies.items():
    hobby_file.write(str(b) + '\n')

users.close()
hobby.close()
hobby_file.close()
