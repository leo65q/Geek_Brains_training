import re

x = open('nginx_logs.txt', 'r', encoding='utf-8')
for a in (x.read().split('\n')):
    if len(a) > 7:
        q = []
        y = re.split('[ "]', a)
        q.append(y[0]), q.append(y[6]), q.append(y[7])
        print(q)
    else:
        continue

x.close()
